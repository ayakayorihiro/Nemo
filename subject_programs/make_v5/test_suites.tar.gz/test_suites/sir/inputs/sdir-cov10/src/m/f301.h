/* Machine description file for Fujitsu F301 machines.  */

/* The following line tells the configuration script what sort of
   operating system this machine is likely to run.
   USUAL-OPSYS="uxpv"  */

#include "delta88k.h"
