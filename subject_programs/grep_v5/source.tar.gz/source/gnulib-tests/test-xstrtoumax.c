/* -*- buffer-read-only: t -*- vi: set ro: */
/* DO NOT EDIT! GENERATED AUTOMATICALLY! */
#define __xstrtol xstrtoumax
#define __strtol_t uintmax_t
#define __spec PRIuMAX
#include "test-xstrtol.c"
