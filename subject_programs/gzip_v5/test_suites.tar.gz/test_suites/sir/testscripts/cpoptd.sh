#!/bin/bash

mv $experiment_root/gzip/inputs/gzdir/file9 $experiment_root/gzip/outputs/test10

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
