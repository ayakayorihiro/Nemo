if [ -f $experiment_root/gzip/inputs/testdir/file11.gz ]
then
  cp $experiment_root/gzip/inputs/testdir/file11.gz $experiment_root/gzip/outputs/test23
else
  cp $experiment_root/gzip/inputs/testdir/file11.z $experiment_root/gzip/outputs/test23
fi

$experiment_root/gzip/testplans.alt/testscripts/cleanup.sh
