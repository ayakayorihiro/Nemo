echo ">>>>>>>>>>>Capturing misplaced files"

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/funny.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/funny.gz

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/funny2.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/funny2.gz

cp ${ARISTOTLE_DB_DIR}/inputs/gzfile/mytar.tar ${ARISTOTLE_DB_DIR}/outputs/gzfile/tared.tar

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/ziptar.tar.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/ziptar.tar.gz

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/.ted.lots.of.dots.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/.ted.lots.of.dots.gz

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/nebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraska.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/nebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraskacomputersciencenebraska.gz

#make script for neb.sure

#make script for 420

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzlikethislikethatlikethisandaitslikethislikethatlielsdjfksdlkfjlkjl123.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzlikethislikethatlikethisandaitslikethislikethatlielsdjfksdlkfjlkjl123.gz

cp ${ARISTOTLE_DB_DIR}/inputs/testfile/nooutQ.gz ${ARISTOTLE_DB_DIR}/outputs/testfile/nooutQ.gz

#make script for noout2
echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>DONE"
