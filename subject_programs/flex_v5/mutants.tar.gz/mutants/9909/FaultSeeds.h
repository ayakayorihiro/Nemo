/* #define F_HD_3 */
/* #define F_HD_4 */
/* #define F_HD_5 */
/* #define F_HD_6 */
/* #define F_AA_3 */
/* #define F_AA_4 */
/* #define F_AA_5 */
/* #define F_JR_1 */
#define F_JR_2
